const regras = (prefix, sender) => {
	return `𝙱𝙴𝙼 𝚅𝙸𝙽𝙳𝙾𝚂 𝙰𝙾 𝙲𝙷𝙰𝚃𝚉𝙸𝙽 𝙳𝙾 𝚉𝙴𝚄𝚂📍
𝑨𝒒𝒖𝒊 𝒆𝒔𝒕𝒂́ 𝒂𝒍𝒈𝒖𝒎𝒂𝒔 𝒓𝒆𝒈𝒓𝒂𝒔

✖️Chamar o bot no privado.
✖️Mandar links sem permissão do adm.
✖️Travas (sujeito a ter WhatsApp desativado)
✖️Gore
✖️Cp
✖️Usar falhas do bot para benefícios
✖️Flood

❕ Quaisquer reclamações ou falhas chame no pv do administrador :)`
}

exports.regras = regras
